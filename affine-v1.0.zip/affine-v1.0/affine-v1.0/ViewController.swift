//
//  ViewController.swift
//  affine-v1.0
//
//  Created by mohamed hammam on 12/12/18.
//  Copyright © 2018 mohamed hammam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mlabel: UITextField!
    @IBOutlet weak var klabel: UITextField!
    @IBOutlet weak var inputlabel: UITextField!
    @IBOutlet weak var outputlabel: UITextField!
    @IBOutlet weak var customizeLabel: UITextField!
    @IBOutlet weak var outputlabel2: UITextField!
    
    
    @IBAction func encryptionButton(_ sender: Any) {
        let M : Int = Int(mlabel.text!)!
        let K : Int = Int(klabel.text!)!
        var inputMessage = "\(inputlabel.text!)"
        var outputMessage = ""
        var doneChar=""
        outputlabel.text = ""
        
        //*******   set language  *********
        var language:String =  customizeLabel.text!
        var  N = language.count
        
        if language.isEmpty == true{
            language = "abcdefghijklmnopqrstuvwxyz"
            N = 26
        }
        
        for outer in 0..<inputMessage.count {
            var inputIndex = inputMessage.index (inputMessage.startIndex, offsetBy: outer)
            //            doneChar.append(inputMessage[inputIndex])
            
            for inner in 0..<N {
                var languageIndex = language.index (language.startIndex, offsetBy: inner)
                
                //if in language and not repeated
                if String( inputMessage [inputIndex]) == String( language [languageIndex])    {
                    
                    let encryptedCharIndex:Int = ((M * inner) + K ) % N
                    var outputCharIndex = language.index (language.startIndex, offsetBy: encryptedCharIndex)
                    outputMessage.append(language[outputCharIndex])
                }
                
            }
        }
        
        outputlabel.text = "\(outputMessage)"
        outputlabel2.text = "\(doneChar) not in language"
    }
    
    
    //*********************************************************//
    //********************************************************//
    @IBAction func decryptioButton(_ sender: Any) {
        let M : Int = Int(mlabel.text!)!
        let K : Int = Int(klabel.text!)!
        
        var inputMessage = "\(inputlabel.text!)"
        var outputMessage = ""
        
        //*******   set language  *********
        var language:String =  customizeLabel.text!
        var  N = language.count
        
        if language.isEmpty{
            language = "abcdefghijklmnopqrstuvwxyz"
            N = 26
        }
        
        // get modular multiplicated inverse
        var mInvers = 0
        for x in 1...26{
            for y in 1...26{
                if x * M - y * N == 1 {
                    mInvers = x
                    break
                }
            }}
        
        for outer in 0..<inputMessage.count {
            var inputIndex = inputMessage.index (inputMessage.startIndex, offsetBy: outer)
            
            for inner in 0..<N {
                var languageIndex = language.index (language.startIndex, offsetBy: inner)
               
                if String( inputMessage [inputIndex]) == String( language [languageIndex]) {
                    
                    var encryptedCharIndex:Int = mInvers * (inner - K) % N
                    
                    while (encryptedCharIndex < 0 ){encryptedCharIndex += N}
                    
                    let outputCharIndex = language.index (language.startIndex, offsetBy: encryptedCharIndex)                   
                    outputMessage.append(language[outputCharIndex])
                    
                }else{
                    outputlabel.text = "not found in language"
                }
            }
        }
        
        outputlabel.text = "\(outputMessage)"
    }
    
    //*************************************************
    override func viewDidLoad() {
        super.viewDidLoad()
        //hide keabord after typing
        self.hideKeyboardWhenTappedAround()
    }
}

//class to hide keboard by touching any where
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
