//
//  ViewController.swift
//  run-length-Encoding
//
//  Created by mohamed hammam on 12/18/18.
//  Copyright © 2018 mohamed hammam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var originalMessageTF: UITextField!
    @IBOutlet weak var compressedMessageTF: UITextField!
    
    @IBAction func EncodeButton(_ sender: Any) {
        //        var originalMessage:String = "mohamed"
        var originalMessage = originalMessageTF.text!
        originalMessage.append(".")
        var compressedMessage:String = ""
        var lastChar = ""
        var length = originalMessage.count
        var count = 1
        for x in 0..<length-1{
            var charIndex = originalMessage.index (originalMessage.startIndex, offsetBy: x)
            var nextCharIndex = originalMessage.index (originalMessage.startIndex, offsetBy: x+1)
            if originalMessage[charIndex] == originalMessage[nextCharIndex]{
                count += 1
            }else{
                var tempMessage =  String(originalMessage[charIndex])
                compressedMessage.append("\(count)\(tempMessage)")
                count = 1
            }
        }
        compressedMessageTF.text = compressedMessage
    }
    
    @IBAction func DecodeButton(_ sender: Any) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.hideKeyboardWhenTappedAround()
    }
    
}
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

